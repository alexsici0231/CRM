import { useEffect, useRef } from 'react';
import { LayoutDashboard, Handshake, Users, Calendar, Settings } from 'lucide-react';
import { motion } from 'framer-motion';
import type { PageId } from '@/types';
import gsap from 'gsap';

interface SidebarProps {
  activePage: PageId;
  onNavigate: (page: PageId) => void;
}

const navItems: { id: PageId; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'deals', label: 'Deals', icon: Handshake },
  { id: 'contacts', label: 'Contacts', icon: Users },
  { id: 'calendar', label: 'Calendar', icon: Calendar },
];

export default function Sidebar({ activePage, onNavigate }: SidebarProps) {
  const sidebarRef = useRef<HTMLDivElement>(null);
  const navRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(sidebarRef.current, {
        x: -240,
        duration: 0.6,
        ease: 'power3.out',
      });

      if (navRef.current) {
        const items = navRef.current.querySelectorAll('.nav-item');
        gsap.from(items, {
          x: -20,
          opacity: 0,
          stagger: 0.05,
          duration: 0.5,
          ease: 'power2.out',
          delay: 0.3,
        });
      }
    });

    return () => ctx.revert();
  }, []);

  return (
    <aside
      ref={sidebarRef}
      className="fixed left-0 top-0 h-screen w-[240px] z-50 flex flex-col border-r border-subtle"
      style={{ backgroundColor: '#0D1321' }}
    >
      {/* Logo */}
      <div className="h-14 flex items-center justify-center gap-2">
        <span className="w-2 h-2 rounded-full bg-[#D97706]" />
        <span
          className="text-base font-bold tracking-[-0.02em]"
          style={{ color: '#F1F5F9' }}
        >
          Octavia
        </span>
      </div>

      {/* Navigation */}
      <nav ref={navRef} className="flex-1 px-3 py-4 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activePage === item.id;
          return (
            <motion.button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`nav-item w-full flex items-center gap-3 px-4 h-10 rounded-lg text-sm transition-all duration-200 cursor-pointer ${
                isActive
                  ? 'font-medium border-l-[3px] border-l-[#D97706]'
                  : 'border-l-[3px] border-l-transparent hover:bg-[rgba(30,42,66,0.5)]'
              }`}
              style={{
                backgroundColor: isActive ? '#1E2A42' : 'transparent',
                color: isActive ? '#F1F5F9' : '#94A3B8',
              }}
              whileHover={{ x: isActive ? 0 : 2 }}
              whileTap={{ scale: 0.98 }}
            >
              <Icon size={20} className={isActive ? 'text-[#F1F5F9]' : 'text-[#64748B]'} />
              <span>{item.label}</span>
            </motion.button>
          );
        })}
      </nav>

      {/* Divider */}
      <div className="mx-5 h-px bg-[rgba(148,163,184,0.1)]" />

      {/* Bottom section */}
      <div className="px-3 py-4 space-y-1">
        <motion.button
          onClick={() => onNavigate('settings')}
          className={`w-full flex items-center gap-3 px-4 h-10 rounded-lg text-sm transition-all duration-200 cursor-pointer ${
            activePage === 'settings'
              ? 'font-medium border-l-[3px] border-l-[#D97706]'
              : 'border-l-[3px] border-l-transparent hover:bg-[rgba(30,42,66,0.5)]'
          }`}
          style={{
            backgroundColor: activePage === 'settings' ? '#1E2A42' : 'transparent',
            color: activePage === 'settings' ? '#F1F5F9' : '#94A3B8',
          }}
          whileHover={{ x: 2 }}
          whileTap={{ scale: 0.98 }}
        >
          <Settings size={20} className={activePage === 'settings' ? 'text-[#F1F5F9]' : 'text-[#64748B]'} />
          <span>Settings</span>
        </motion.button>

        {/* User profile */}
        <div className="flex items-center gap-3 px-4 py-3 mt-2">
          <img
            src="/assets/avatar-alex.jpg"
            alt="Alex Johnson"
            className="w-8 h-8 rounded-full object-cover"
          />
          <div className="flex flex-col">
            <span className="text-[13px] font-medium" style={{ color: '#F1F5F9' }}>
              Alex Johnson
            </span>
            <span className="text-xs" style={{ color: '#64748B' }}>
              Manager
            </span>
          </div>
        </div>
      </div>
    </aside>
  );
}
