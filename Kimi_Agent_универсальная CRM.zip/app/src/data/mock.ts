import type { Deal, Contact, Task, Meeting, Message, CalendarEvent } from '@/types';

export const deals: Deal[] = [
  { id: '1', company: 'Acme Inc', dealName: 'Enterprise License', stage: 'Proposal Sent', value: 45000, lastActivity: '2 hours ago', owner: 'Alex Johnson', ownerAvatar: '/assets/avatar-alex.jpg', priority: 'high', daysInStage: 5 },
  { id: '2', company: 'Globex Corp', dealName: 'Consulting Package', stage: 'Negotiation', value: 28500, lastActivity: '5 hours ago', owner: 'Sarah Chen', ownerAvatar: '/assets/avatar-sarah.jpg', priority: 'medium', daysInStage: 3 },
  { id: '3', company: 'Soylent Co', dealName: 'Annual Contract', stage: 'Discovery', value: 62000, lastActivity: '1 day ago', owner: 'Michael Ross', ownerAvatar: '/assets/avatar-michael.jpg', priority: 'high', daysInStage: 8 },
  { id: '4', company: 'Initech LLC', dealName: 'Team Upgrade', stage: 'Proposal Sent', value: 18200, lastActivity: '1 day ago', owner: 'Alex Johnson', ownerAvatar: '/assets/avatar-alex.jpg', priority: 'low', daysInStage: 4 },
  { id: '5', company: 'Umbrella Enterprises', dealName: 'Custom Integration', stage: 'Negotiation', value: 95000, lastActivity: '2 days ago', owner: 'Emma Wilson', ownerAvatar: '/assets/avatar-emma.jpg', priority: 'high', daysInStage: 6 },
  { id: '6', company: 'Stark Industries', dealName: 'Platform License', stage: 'New Lead', value: 78000, lastActivity: '3 hours ago', owner: 'Sarah Chen', ownerAvatar: '/assets/avatar-sarah.jpg', priority: 'medium', daysInStage: 1 },
  { id: '7', company: 'Wayne Corp', dealName: 'Enterprise Deal', stage: 'New Lead', value: 120000, lastActivity: '1 day ago', owner: 'Michael Ross', ownerAvatar: '/assets/avatar-michael.jpg', priority: 'high', daysInStage: 2 },
  { id: '8', company: 'Cyberdyne', dealName: 'AI Integration', stage: 'Discovery', value: 54000, lastActivity: '4 hours ago', owner: 'Alex Johnson', ownerAvatar: '/assets/avatar-alex.jpg', priority: 'medium', daysInStage: 5 },
  { id: '9', company: 'Massive Dynamic', dealName: 'Research Package', stage: 'Discovery', value: 35000, lastActivity: '6 hours ago', owner: 'Emma Wilson', ownerAvatar: '/assets/avatar-emma.jpg', priority: 'low', daysInStage: 3 },
  { id: '10', company: 'Oceanic Airlines', dealName: 'Service Contract', stage: 'New Lead', value: 22000, lastActivity: '2 days ago', owner: 'Sarah Chen', ownerAvatar: '/assets/avatar-sarah.jpg', priority: 'low', daysInStage: 1 },
  { id: '11', company: 'Dharma Initiative', dealName: 'Research Funding', stage: 'Proposal Sent', value: 67000, lastActivity: '12 hours ago', owner: 'Michael Ross', ownerAvatar: '/assets/avatar-michael.jpg', priority: 'medium', daysInStage: 7 },
  { id: '12', company: 'Aperture Science', dealName: 'Portal Tech', stage: 'Closed Won', value: 89000, lastActivity: '1 week ago', owner: 'Alex Johnson', ownerAvatar: '/assets/avatar-alex.jpg', priority: 'high', daysInStage: 0 },
  { id: '13', company: 'Black Mesa', dealName: 'Research Grant', stage: 'Closed Won', value: 110000, lastActivity: '3 days ago', owner: 'Emma Wilson', ownerAvatar: '/assets/avatar-emma.jpg', priority: 'medium', daysInStage: 0 },
  { id: '14', company: 'Tyrell Corp', dealName: 'Replicant License', stage: 'Discovery', value: 150000, lastActivity: '8 hours ago', owner: 'Sarah Chen', ownerAvatar: '/assets/avatar-sarah.jpg', priority: 'high', daysInStage: 4 },
  { id: '15', company: 'Weyland-Yutani', dealName: 'Colony Contract', stage: 'Proposal Sent', value: 200000, lastActivity: '1 day ago', owner: 'Michael Ross', ownerAvatar: '/assets/avatar-michael.jpg', priority: 'high', daysInStage: 10 },
  { id: '16', company: 'Omni Consumer', dealName: 'Product Line', stage: 'New Lead', value: 31000, lastActivity: '5 hours ago', owner: 'Alex Johnson', ownerAvatar: '/assets/avatar-alex.jpg', priority: 'low', daysInStage: 1 },
  { id: '17', company: 'Gringotts Bank', dealName: 'Vault Security', stage: 'Negotiation', value: 75000, lastActivity: '3 days ago', owner: 'Emma Wilson', ownerAvatar: '/assets/avatar-emma.jpg', priority: 'medium', daysInStage: 8 },
];

export const contacts: Contact[] = [
  { id: '1', firstName: 'John', lastName: 'Smith', email: 'john@acmeinc.com', phone: '+1 (555) 123-4567', title: 'VP of Sales', company: 'Acme Inc', avatar: '/assets/company-logo-acme.jpg', tags: ['Enterprise', 'VIP'], lastContacted: '2 days ago', engagementScore: 85 },
  { id: '2', firstName: 'Lisa', lastName: 'Wong', email: 'lisa@globex.com', phone: '+1 (555) 234-5678', title: 'Procurement Manager', company: 'Globex Corp', avatar: '/assets/company-logo-globex.jpg', tags: ['Mid-Market'], lastContacted: '5 hours ago', engagementScore: 72 },
  { id: '3', firstName: 'Robert', lastName: 'Green', email: 'robert@soylent.com', phone: '+1 (555) 345-6789', title: 'CEO', company: 'Soylent Co', avatar: '/assets/company-logo-soylent.jpg', tags: ['Enterprise', 'Decision Maker'], lastContacted: '1 day ago', engagementScore: 91 },
  { id: '4', firstName: 'Milton', lastName: 'Waddams', email: 'milton@initech.com', phone: '+1 (555) 456-7890', title: 'IT Manager', company: 'Initech LLC', avatar: '/assets/company-logo-acme.jpg', tags: ['SMB'], lastContacted: '3 days ago', engagementScore: 45 },
  { id: '5', firstName: 'Albert', lastName: 'Wesker', email: 'awesker@umbrella.com', phone: '+1 (555) 567-8901', title: 'Director of Operations', company: 'Umbrella Enterprises', avatar: '/assets/company-logo-globex.jpg', tags: ['Enterprise', 'VIP'], lastContacted: '1 week ago', engagementScore: 68 },
  { id: '6', firstName: 'Tony', lastName: 'Stark', email: 'tony@stark.com', phone: '+1 (555) 678-9012', title: 'CEO', company: 'Stark Industries', avatar: '/assets/company-logo-acme.jpg', tags: ['Enterprise', 'VIP', 'Decision Maker'], lastContacted: '3 hours ago', engagementScore: 95 },
  { id: '7', firstName: 'Bruce', lastName: 'Wayne', email: 'bruce@wayne.com', phone: '+1 (555) 789-0123', title: 'Chairman', company: 'Wayne Corp', avatar: '/assets/company-logo-globex.jpg', tags: ['Enterprise', 'VIP'], lastContacted: '2 days ago', engagementScore: 88 },
  { id: '8', firstName: 'Sarah', lastName: 'Connor', email: 'sarah@cyberdyne.com', phone: '+1 (555) 890-1234', title: 'CTO', company: 'Cyberdyne', avatar: '/assets/company-logo-soylent.jpg', tags: ['Enterprise', 'Technical'], lastContacted: '4 hours ago', engagementScore: 76 },
  { id: '9', firstName: 'Walter', lastName: 'Bishop', email: 'walter@massivedynamic.com', phone: '+1 (555) 901-2345', title: 'Chief Scientist', company: 'Massive Dynamic', avatar: '/assets/company-logo-acme.jpg', tags: ['Mid-Market', 'Technical'], lastContacted: '6 hours ago', engagementScore: 63 },
  { id: '10', firstName: 'Jack', lastName: 'Shephard', email: 'jack@oceanic.com', phone: '+1 (555) 012-3456', title: 'Operations Lead', company: 'Oceanic Airlines', avatar: '/assets/company-logo-globex.jpg', tags: ['SMB'], lastContacted: '2 days ago', engagementScore: 54 },
  { id: '11', firstName: 'Desmond', lastName: 'Hume', email: 'desmond@dharma.com', phone: '+1 (555) 111-2222', title: 'Research Director', company: 'Dharma Initiative', avatar: '/assets/company-logo-soylent.jpg', tags: ['Mid-Market', 'Technical'], lastContacted: '12 hours ago', engagementScore: 71 },
  { id: '12', firstName: 'Cave', lastName: 'Johnson', email: 'cave@aperture.com', phone: '+1 (555) 222-3333', title: 'Founder', company: 'Aperture Science', avatar: '/assets/company-logo-acme.jpg', tags: ['Enterprise', 'VIP', 'Decision Maker'], lastContacted: '1 week ago', engagementScore: 92 },
];

export const tasks: Task[] = [
  { id: '1', title: 'Follow up with Acme Inc', completed: false, time: '10:00 AM', date: '2025-03-17' },
  { id: '2', title: 'Prepare proposal for Globex', completed: false, time: '11:30 AM', date: '2025-03-17' },
  { id: '3', title: 'Call with Soylent Co team', completed: true, time: '2:00 PM', date: '2025-03-17' },
  { id: '4', title: 'Review contract terms', completed: false, time: '4:00 PM', date: '2025-03-17' },
];

export const meetings: Meeting[] = [
  { id: '1', title: 'Standup', time: '9:00 AM', duration: '15 min', attendees: ['Alex', 'Sarah', 'Michael'] },
  { id: '2', title: 'Acme Inc — Proposal Review', time: '10:00 AM', duration: '45 min', attendees: ['Alex', 'John'] },
  { id: '3', title: 'Soylent Co — Discovery Call', time: '2:00 PM', duration: '30 min', attendees: ['Alex', 'Robert'] },
];

export const messages: Message[] = [
  { id: '1', sender: 'Sarah Chen', senderAvatar: '/assets/avatar-sarah.jpg', subject: 'Re: Globex proposal', preview: "I've reviewed the terms and we have a few questions about the pricing structure...", time: '10:32 AM', unread: true },
  { id: '2', sender: 'Mike Ross', senderAvatar: '/assets/avatar-michael.jpg', subject: 'Soylent contract', preview: 'Can we schedule a call to discuss the deliverables and timeline?', time: 'Yesterday', unread: true },
  { id: '3', sender: 'Emma Wilson', senderAvatar: '/assets/avatar-emma.jpg', subject: 'Umbrella integration specs', preview: "I've attached the technical requirements document for your review...", time: 'Yesterday', unread: false },
  { id: '4', sender: 'Tony Stark', senderAvatar: '/assets/avatar-alex.jpg', subject: 'Stark Industries — Q2 Plans', preview: "Let's discuss the upcoming quarter's objectives and targets.", time: 'Mar 15', unread: false },
];

export const calendarEvents: CalendarEvent[] = [
  { id: '1', title: 'Standup', startTime: '09:00', endTime: '09:15', date: new Date(2025, 2, 17), color: 'green', attendees: ['Alex', 'Sarah', 'Michael'], location: 'Zoom' },
  { id: '2', title: 'Acme Inc — Proposal Review', startTime: '10:00', endTime: '10:45', date: new Date(2025, 2, 17), color: 'blue', attendees: ['Alex', 'John Smith'], location: 'Conference Room A' },
  { id: '3', title: 'Soylent Co — Discovery', startTime: '14:00', endTime: '14:30', date: new Date(2025, 2, 17), color: 'orange', attendees: ['Alex', 'Robert Green'], location: 'Google Meet' },
  { id: '4', title: 'Contract Review', startTime: '16:00', endTime: '16:30', date: new Date(2025, 2, 17), color: 'purple', attendees: ['Alex'], location: 'Office' },
  { id: '5', title: 'Team Lunch', startTime: '12:00', endTime: '13:00', date: new Date(2025, 2, 18), color: 'green', attendees: ['Alex', 'Sarah', 'Michael', 'Emma'], location: 'Cafeteria' },
  { id: '6', title: 'Globex Corp — Follow-up', startTime: '11:00', endTime: '11:30', date: new Date(2025, 2, 18), color: 'blue', attendees: ['Alex', 'Lisa Wong'], location: 'Zoom' },
  { id: '7', title: 'Q1 Review', startTime: '15:00', endTime: '16:00', date: new Date(2025, 2, 19), color: 'purple', attendees: ['Alex', 'Sarah', 'Michael', 'Emma'], location: 'Board Room' },
  { id: '8', title: 'Initech — Demo', startTime: '10:00', endTime: '10:45', date: new Date(2025, 2, 20), color: 'orange', attendees: ['Alex', 'Milton Waddams'], location: 'Google Meet' },
  { id: '9', title: 'Pipeline Review', startTime: '14:00', endTime: '15:00', date: new Date(2025, 2, 20), color: 'blue', attendees: ['Alex', 'Sarah'], location: 'Conference Room B' },
  { id: '10', title: 'Stark Industries — Kickoff', startTime: '09:30', endTime: '10:30', date: new Date(2025, 2, 21), color: 'green', attendees: ['Alex', 'Tony Stark'], location: 'Zoom' },
];

export const sparklineData = [
  [42000, 45000, 48000, 52000, 58000, 62000, 68000, 72000, 85000, 92000, 110000, 142580],
  [18, 19, 20, 21, 20, 22, 23, 22, 24, 23, 24, 24],
  [52, 53, 55, 56, 58, 60, 61, 63, 65, 66, 67, 68],
  [12, 11, 10, 9, 10, 8, 9, 8, 7, 8, 7, 7],
];

export const winRateData = [
  { stage: 'New Lead', rate: 85, color: '#06B6D4' },
  { stage: 'Discovery', rate: 72, color: '#3B82F6' },
  { stage: 'Proposal', rate: 58, color: '#F97316' },
  { stage: 'Negotiation', rate: 45, color: '#A855F7' },
];

export const revenueForecast = [
  { week: 'W1', value: 32000 },
  { week: 'W2', value: 45000 },
  { week: 'W3', value: 38000 },
  { week: 'W4', value: 52000 },
];
