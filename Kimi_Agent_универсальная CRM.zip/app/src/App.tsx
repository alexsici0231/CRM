import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Sidebar from '@/components/Sidebar';
import AIAssistant from '@/components/AIAssistant';
import Dashboard from '@/pages/Dashboard';
import Deals from '@/pages/Deals';
import Contacts from '@/pages/Contacts';
import CalendarPage from '@/pages/Calendar';
import Settings from '@/pages/Settings';
import type { PageId } from '@/types';

export default function App() {
  const [activePage, setActivePage] = useState<PageId>('dashboard');

  const renderPage = () => {
    switch (activePage) {
      case 'dashboard':
        return <Dashboard />;
      case 'deals':
        return <Deals />;
      case 'contacts':
        return <Contacts />;
      case 'calendar':
        return <CalendarPage />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden" style={{ backgroundColor: '#0B1120' }}>
      <Sidebar activePage={activePage} onNavigate={setActivePage} />

      <main className="flex-1 ml-[240px] overflow-y-auto overflow-x-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={activePage}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          >
            {renderPage()}
          </motion.div>
        </AnimatePresence>
      </main>

      <AIAssistant />
    </div>
  );
}
